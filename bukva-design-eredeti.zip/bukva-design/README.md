# bukva.design – weboldal

Statikus, kétnyelvű (HU/EN) weboldal. Nincs keretrendszer és nincs adatbázis: gyors, biztonságos, bárhol ingyen hosztolható.

## Mappák
- `dist/` – **a kész, feltölthető weboldal.** Ezt kell a tárhelyre tenni.
- `src/assets/` – CSS, JS, betűtípusok, ikonok, megosztási kép (og-image).
- `build/` – a generátor (`build.py`) és a tartalom (`content_hu.py`, `content_en.py`).

## Szöveg módosítása
1. Szerkeszd a `build/content_hu.py` vagy `build/content_en.py` fájlt (sima HTML).
2. Futtasd: `python3 build/build.py` → frissül a `dist/` mappa, a sitemap és a többi SEO-fájl.

## Élesítés (pl. Netlify vagy Cloudflare Pages, ingyenes)
1. Húzd be a `dist/` mappát a Netlify Drop / Cloudflare Pages felületére.
2. Állítsd be a `bukva.design` domaint a DNS-ben.
3. Google Search Console: add hozzá a domaint, és küldd be a `https://bukva.design/sitemap.xml` címet.
4. Hozd létre a Google Cégprofilt (szolgáltatási területtel, cím nélkül is lehet).

## Kapcsolati űrlap bekötése
A `kapcsolat.html` és `en/contact.html` űrlapján a `data-endpoint=""` üres, ilyenkor előnézeti módban fut.
Formspree esetén: regisztrálj, és írd be a végpontot: `data-endpoint="https://formspree.io/f/XXXXXXX"` (a `build/content_*.py` fájlokban, majd build).

## Ügyfélvélemény hozzáadása (főoldal)
A `build/content_hu.py` (és `content_en.py`) elején a `TESTIMONIALS = []` listába írd be az idézetet a megadott minta szerint, majd futtasd a `python3 build/build.py` parancsot. Üres lista esetén a rész nem jelenik meg. Csak valódi, írásban engedélyezett idézetet használj.

## Élesítés előtti teendők
- [ ] `hello@bukva.design` e-mail-cím létrehozása (vagy csere a `content_*.py` fájlokban)
- [ ] ÁFA-státusz feltüntetése az árak alatt (könyvelővel egyeztetve) – lásd TODO a `content_hu.py`-ban
- [ ] Adatkezelési tájékoztató véglegesítése jogásszal ([szögletes zárójeles] részek), majd a `noindex` levétele
- [ ] Esettanulmányok és ügyfélvélemény (sablonok a `munkaim` oldal kódjában)
- [ ] Portréfotó: `src/assets/portrait.webp`, majd a helyőrzők cseréje (Rólam oldal + főoldali CTA, lásd HTML-kommentek)
- [ ] Kézi teszt képernyőolvasóval (NVDA / VoiceOver) – az automatikus axe-teszt hibátlan
- [ ] Fizetési feltételek (50/50) és határidők ellenőrzése a GYIK-ben

## Ami már benne van
- WCAG 2.2 AA: szemantikus HTML, billentyűzetes navigáció, látható fókusz, „Ugrás a tartalomra”, ≥ 4,5:1 kontraszt (többnyire 7:1+), 44 px-es érintési célok, csökkentett mozgás, sötét mód, High Contrast mód, akadálymentes űrlap hibaösszesítővel
- SEO: egyedi title/description, canonical, hreflang (hu/en), Open Graph kép, schema.org (ProfessionalService, Person, FAQPage, BreadcrumbList), sitemap.xml, robots.txt, llms.txt (AI-keresőknek)
- GDPR: saját tárhelyről betöltött betűtípusok (nincs Google Fonts hívás), nincs követő süti
- Teljesítmény: nincs külső függőség, ~25 KB CSS + 8 KB JS, tömörítve ennek töredéke
